// HospiCare – Alandi hospital map
// Uses Leaflet + OpenStreetMap + Overpass API + OSRM. No API keys needed.

document.addEventListener("DOMContentLoaded", function () {
  // ---------------------------------------------------------------
  // 1. SETTINGS (change these if you want a different area)
  // ---------------------------------------------------------------
  const CENTER = [18.6776, 73.8987];
  const DEFAULT_ZOOM = 14;
  // Search/pan area: south, west, north, east
  const BBOX = { south: 18.64, west: 73.85, north: 18.72, east: 73.95 };
  const OVERPASS_URLS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter"
  ];
  const OSRM_URL = "https://router.project-osrm.org/route/v1/driving/";
  const LABEL_MIN_ZOOM = 14; // labels are hidden when zoomed out further than this

  // ---------------------------------------------------------------
  // 2. PAGE ELEMENTS
  // ---------------------------------------------------------------
  const btnLocate = document.getElementById("btn-locate");
  const btnNearest = document.getElementById("btn-nearest");
  const btnRoute = document.getElementById("btn-route");
  const btnClearRoute = document.getElementById("btn-clear-route");
  const btnReset = document.getElementById("btn-reset");
  const searchInput = document.getElementById("search-input");
  const searchResults = document.getElementById("search-results");
  const filterSelect = document.getElementById("filter-select");
  const countText = document.getElementById("hospital-count");
  const resultContent = document.getElementById("result-content");
  const statusBox = document.getElementById("status");
  const mapDiv = document.getElementById("map");

  // ---------------------------------------------------------------
  // 3. STATE
  // ---------------------------------------------------------------
  let hospitals = [];          // all hospitals loaded from OpenStreetMap
  let hospitalsLoaded = false;
  let userLatLng = null;       // set only after the user gives permission
  let userMarker = null;
  let selectedHospital = null; // hospital used for nearest / route
  let nearestLine = null;      // straight line
  let routeLine = null;        // road route
  let markerLayer = L.layerGroup();
  let busy = { locate: false, hospitals: false, route: false };

  // ---------------------------------------------------------------
  // 4. MAP SETUP
  // ---------------------------------------------------------------
  const bounds = L.latLngBounds([BBOX.south, BBOX.west], [BBOX.north, BBOX.east]);
  const map = L.map("map", {
    center: CENTER,
    zoom: DEFAULT_ZOOM,
    minZoom: 13,
    maxZoom: 19,
    maxBounds: bounds.pad(0.1),
    maxBoundsViscosity: 1.0
  });

  
const tiles = L.tileLayer("https://tile.openstreetmap.de/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);


  let tileErrorShown = false;
  tiles.on("tileerror", function () {
    if (!tileErrorShown) {
      tileErrorShown = true;
      showStatus("Some map tiles could not be loaded. Check your internet connection.", "error");
    }
  });
  tiles.on("tileload", function () {
    if (tileErrorShown) { tileErrorShown = false; hideStatus(); }
  });

  markerLayer.addTo(map);
  L.control.scale({ imperial: false }).addTo(map);

  // Hide labels when zoomed out so markers do not cover the map
  function updateLabelVisibility() {
    mapDiv.classList.toggle("hide-labels", map.getZoom() < LABEL_MIN_ZOOM);
  }
  map.on("zoomend", updateLabelVisibility);
  updateLabelVisibility();

  // ---------------------------------------------------------------
  // 5. SMALL HELPERS
  // ---------------------------------------------------------------
  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = String(text);
    return div.innerHTML;
  }

  function showStatus(message, type, retryFn) {
    statusBox.className = "status " + (type || "info");
    statusBox.textContent = message;
    if (retryFn) {
      const b = document.createElement("button");
      b.textContent = "Retry";
      b.addEventListener("click", retryFn);
      statusBox.appendChild(b);
    }
    statusBox.hidden = false;
  }

  function hideStatus() { statusBox.hidden = true; }

  function formatKm(metres) { return (metres / 1000).toFixed(2) + " km"; }

  function formatDuration(seconds) {
    const mins = Math.round(seconds / 60);
    if (mins < 60) return mins + " min";
    return Math.floor(mins / 60) + " h " + (mins % 60) + " min";
  }

  function isValidCoord(lat, lon) {
    return typeof lat === "number" && typeof lon === "number" &&
      isFinite(lat) && isFinite(lon) &&
      lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180;
  }

  function straightDistance(h) {
    // Straight-line distance in metres using Leaflet
    return userLatLng ? userLatLng.distanceTo(L.latLng(h.lat, h.lon)) : null;
  }

  function hospitalLabel(h) { return h.name || "Unnamed hospital"; }

  // Rating snapshot for named hospitals in Alandi. Values may change; unmatched hospitals show no rating.
  const ALANDI_RATINGS = [
    { match: ["k k multispeciality", "kk multispeciality"], rating: "4.9", reviews: "1,915" },
    { match: ["anand multispeciality"], rating: "4.9", reviews: "457" },
    { match: ["amrut hospital"], rating: "4.8", reviews: "351" },
    { match: ["siddhivinayak"], rating: "4.9", reviews: "622" },
    { match: ["indrayani hospital"], rating: "4.3", reviews: "479" },
    { match: ["shiv hospital"], rating: "5.0", reviews: "90" }
  ];

  function getHospitalRating(h) {
    const name = (h.name || "").toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
    return ALANDI_RATINGS.find(function (item) {
      return item.match.some(function (term) { return name.includes(term); });
    }) || null;
  }

  // ---------------------------------------------------------------
  // 6. LOAD HOSPITALS FROM OVERPASS
  // ---------------------------------------------------------------
  async function fetchOverpass(query) {
    let lastError = null;
    for (const url of OVERPASS_URLS) {
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 30000);
        const response = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: "data=" + encodeURIComponent(query),
          signal: controller.signal
        });
        clearTimeout(timer);
        if (response.status === 429) throw new Error("Too many requests (rate limit). Wait a minute.");
        if (!response.ok) throw new Error("Server returned status " + response.status);
        return await response.json();
      } catch (err) {
        lastError = err;
      }
    }
    throw lastError || new Error("Unknown error");
  }

  function buildAddress(tags) {
    if (tags["addr:full"]) return tags["addr:full"];
    const parts = [
      [tags["addr:housenumber"], tags["addr:street"]].filter(Boolean).join(" "),
      tags["addr:suburb"], tags["addr:city"], tags["addr:postcode"]
    ].filter(Boolean);
    return parts.join(", ");
  }

  function parseElements(elements) {
    const list = [];
    elements.forEach(function (el) {
      const tags = el.tags || {};
      // Nodes have lat/lon; ways and relations have "center"
      const lat = el.lat !== undefined ? el.lat : (el.center && el.center.lat);
      const lon = el.lon !== undefined ? el.lon : (el.center && el.center.lon);
      if (!isValidCoord(lat, lon)) return;
      list.push({
        key: el.type + "/" + el.id,
        type: el.type,
        id: el.id,
        name: tags.name || tags["name:en"] || "",
        lat: lat,
        lon: lon,
        address: buildAddress(tags),
        phone: tags.phone || tags["contact:phone"] || "",
        website: tags.website || tags["contact:website"] || "",
        roadMetres: null,
        marker: null
      });
    });
    return removeDuplicates(list);
  }

  // Same facility may be mapped as a node AND a building outline.
  // Treat two records as duplicates if they have the same name and are within 150 m,
  // or if one has no name and they are within 30 m.
  function removeDuplicates(list) {
    const result = [];
    list.forEach(function (h) {
      const p = L.latLng(h.lat, h.lon);
      const dupIndex = result.findIndex(function (other) {
        const d = p.distanceTo(L.latLng(other.lat, other.lon));
        const sameName = h.name && other.name && h.name.toLowerCase() === other.name.toLowerCase();
        return (sameName && d < 150) || ((!h.name || !other.name) && d < 30);
      });
      if (dupIndex === -1) {
        result.push(h);
      } else if (!result[dupIndex].name && h.name) {
        result[dupIndex] = h; // keep the record that has a name
      }
    });
    return result;
  }

  async function loadHospitals() {
    if (busy.hospitals) return;
    busy.hospitals = true;
    hospitalsLoaded = false;
    showStatus("Loading hospitals from OpenStreetMap…", "info");

    const bb = [BBOX.south, BBOX.west, BBOX.north, BBOX.east].join(",");
    const query = '[out:json][timeout:25];nwr["amenity"="hospital"](' + bb + ');out center tags;';

    try {
      const data = await fetchOverpass(query);
      hospitals = parseElements(data.elements || []);
      hospitalsLoaded = true;
      hideStatus();
      if (hospitals.length === 0) {
        showStatus("No hospitals were found in OpenStreetMap for this area.", "error", loadHospitals);
      }
      renderMarkers();
    } catch (err) {
      showStatus("Could not load hospitals: " + err.message, "error", loadHospitals);
    } finally {
      busy.hospitals = false;
    }
  }

  // ---------------------------------------------------------------
  // 7. MARKERS, FILTER, POPUPS
  // ---------------------------------------------------------------
  function passesFilter(h) {
    const f = filterSelect.value;
    if (f === "address") return !!h.address;
    if (f === "contact") return !!(h.phone || h.website);
    return true;
  }

  function makeIcon(h, isNearest) {
    const rating = getHospitalRating(h);
    const ratingHtml = rating
      ? '<span class="h-rating">★ ' + rating.rating + ' <small>(' + rating.reviews + ')</small></span>'
      : '';
    const html =
      '<div class="h-pin"><span class="h-cross">+</span>' +
      '<span class="h-label"><span class="h-name">' + escapeHtml(hospitalLabel(h)) +
      '</span>' + ratingHtml + '</span></div>';
    return L.divIcon({
      className: "hospital-icon" + (isNearest ? " nearest" : ""),
      html: html,
      iconSize: [28, 28],
      iconAnchor: [14, 14],
      popupAnchor: [0, -14]
    });
  }

  function popupHtml(h) {
    let html = '<div class="popup"><h3>' + escapeHtml(hospitalLabel(h)) + "</h3>";
    if (h.address) html += "<p><b>Address:</b> " + escapeHtml(h.address) + "</p>";
    const d = straightDistance(h);
    if (d !== null) html += "<p><b>Straight-line distance:</b> " + formatKm(d) + "</p>";
    if (h.roadMetres !== null) html += "<p><b>Road distance:</b> " + formatKm(h.roadMetres) + "</p>";
    if (h.phone) html += "<p><b>Phone:</b> " + escapeHtml(h.phone) + "</p>";
    if (h.website && /^https?:\/\//i.test(h.website)) {
      html += '<p><b>Website:</b> <a href="' + escapeHtml(h.website) + '" target="_blank" rel="noopener">' +
        escapeHtml(h.website) + "</a></p>";
    }
    html += '<button class="popup-btn" data-route="' + escapeHtml(h.key) + '">Show Route</button>';
    html += '<p><a href="https://www.openstreetmap.org/' + h.type + "/" + h.id +
      '" target="_blank" rel="noopener">Open in OpenStreetMap</a></p>';
    if (h.name) {
      html += '<p><a href="https://www.google.com/maps/search/?api=1&query=' +
        encodeURIComponent(h.name + " Alandi Pune") +
        '" target="_blank" rel="noopener">Open this hospital on Google Maps</a></p>';
    }
    return html + "</div>";
  }

  function renderMarkers() {
    markerLayer.clearLayers();
    let shown = 0;
    hospitals.forEach(function (h) {
      h.marker = null;
      if (!passesFilter(h)) return;
      const isNearest = selectedHospital && selectedHospital.key === h.key;
      const m = L.marker([h.lat, h.lon], {
        icon: makeIcon(h, isNearest),
        title: hospitalLabel(h),
        zIndexOffset: isNearest ? 1000 : 0
      });
      m.bindPopup(function () { return popupHtml(h); });
      m.addTo(markerLayer);
      h.marker = m;
      shown++;
    });
    countText.textContent = hospitalsLoaded
      ? "Showing " + shown + " of " + hospitals.length + " hospitals loaded. Data may be incomplete."
      : "";
  }

  // "Show Route" buttons inside popups
  map.on("popupopen", function (e) {
    const btn = e.popup.getElement().querySelector("[data-route]");
    if (!btn) return;
    btn.addEventListener("click", function () {
      const h = hospitals.find(function (x) { return x.key === btn.getAttribute("data-route"); });
      if (h) { selectHospital(h); showRoute(); }
    });
  });

  function selectHospital(h) {
    selectedHospital = h;
    btnRoute.disabled = false;
    renderMarkers();
  }

  // ---------------------------------------------------------------
  // 8. USER LOCATION
  // ---------------------------------------------------------------
  function getUserLocation() {
    return new Promise(function (resolve, reject) {
      if (!navigator.geolocation) {
        reject(new Error("Your browser does not support geolocation."));
        return;
      }
      navigator.geolocation.getCurrentPosition(
        function (pos) { resolve(L.latLng(pos.coords.latitude, pos.coords.longitude)); },
        function (err) {
          const messages = {
            1: "Location permission was denied. Allow location access in your browser and try again.",
            2: "Your location could not be determined.",
            3: "Getting your location took too long. Please try again."
          };
          reject(new Error(messages[err.code] || "Could not get your location."));
        },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
      );
    });
  }

  async function useMyLocation(centerMap) {
    if (busy.locate) return false;
    busy.locate = true;
    btnLocate.disabled = true;
    showStatus("Getting your location…", "info");
    try {
      userLatLng = await getUserLocation();
      if (userMarker) map.removeLayer(userMarker);
      userMarker = L.marker(userLatLng, {
        icon: L.divIcon({ className: "", html: '<div class="user-dot"></div>', iconSize: [18, 18], iconAnchor: [9, 9] }),
        zIndexOffset: 2000
      }).addTo(map).bindPopup("Your Current Location");
      hideStatus();
      if (!bounds.contains(userLatLng)) {
        showStatus("You appear to be outside the Alandi area shown on this map.", "info");
      } else if (centerMap) {
        map.setView(userLatLng, 16);
        userMarker.openPopup();
      }
      return true;
    } catch (err) {
      showStatus(err.message, "error");
      return false;
    } finally {
      busy.locate = false;
      btnLocate.disabled = false;
    }
  }

  // ---------------------------------------------------------------
  // 9. NEAREST HOSPITAL (straight-line)
  // ---------------------------------------------------------------
  function clearRoute() {
    if (routeLine) { map.removeLayer(routeLine); routeLine = null; }
  }

  function clearNearestLine() {
    if (nearestLine) { map.removeLayer(nearestLine); nearestLine = null; }
  }

  function showResult(html) { resultContent.innerHTML = html; }

  async function findNearest() {
    if (!userLatLng) {
      const ok = await useMyLocation(false);
      if (!ok) return;
    }
    if (!hospitalsLoaded) {
      showStatus("Hospital data has not loaded yet. Please wait or retry.", "error", loadHospitals);
      return;
    }
    if (hospitals.length === 0) {
      showResult("<p>No hospital data is available, so the nearest hospital cannot be found.</p>");
      return;
    }

    let nearest = null;
    let best = Infinity;
    hospitals.forEach(function (h) {
      const d = straightDistance(h);
      if (d < best) { best = d; nearest = h; }
    });

    clearRoute();
    clearNearestLine();
    selectHospital(nearest);

    nearestLine = L.polyline([userLatLng, [nearest.lat, nearest.lon]], {
      color: "#d32f2f", weight: 3, dashArray: "8 8"
    }).addTo(map);

    map.fitBounds(L.latLngBounds([userLatLng, [nearest.lat, nearest.lon]]), { padding: [60, 60] });

    showResult(
      '<p class="result-line"><b>Nearest Hospital:</b> ' + escapeHtml(hospitalLabel(nearest)) + "</p>" +
      '<p class="result-line"><b>Straight-line Distance:</b> ' + formatKm(best) + "</p>" +
      '<p class="tag-note">This is NOT the driving distance. Press “Show Route” for the road distance. ' +
      "It is the nearest hospital in the loaded data, which may be incomplete.</p>"
    );

    if (nearest.marker) nearest.marker.openPopup();
  }

  // ---------------------------------------------------------------
  // 10. ROAD ROUTE (OSRM)
  // ---------------------------------------------------------------
  async function showRoute() {
    if (busy.route) return;
    if (!selectedHospital) {
      showStatus("Select a hospital first (search or Find Nearest Hospital).", "error");
      return;
    }
    if (!userLatLng) {
      const ok = await useMyLocation(false);
      if (!ok) return;
    }

    busy.route = true;
    btnRoute.disabled = true;
    showStatus("Calculating road route…", "info");
    const h = selectedHospital;

    try {
      // OSRM expects longitude,latitude order
      const url = OSRM_URL + userLatLng.lng + "," + userLatLng.lat + ";" + h.lon + "," + h.lat +
        "?overview=full&geometries=geojson";
      const response = await fetch(url);
      if (!response.ok) throw new Error("Routing service returned status " + response.status);
      const data = await response.json();
      if (data.code !== "Ok" || !data.routes || data.routes.length === 0) {
        throw new Error("No road route was found.");
      }
      const route = data.routes[0];
      const latlngs = route.geometry.coordinates.map(function (c) { return [c[1], c[0]]; });

      clearRoute();
      clearNearestLine();
      routeLine = L.polyline(latlngs, { color: "#1565c0", weight: 5, opacity: 0.85 }).addTo(map);
      map.fitBounds(routeLine.getBounds(), { padding: [60, 60] });

      h.roadMetres = route.distance;
      hideStatus();
      const straight = straightDistance(h);
      showResult(
        '<p class="result-line"><b>Hospital:</b> ' + escapeHtml(hospitalLabel(h)) + "</p>" +
        '<p class="result-line"><b>Road Distance:</b> ' + formatKm(route.distance) + "</p>" +
        '<p class="result-line"><b>Estimated Travel Time:</b> ' + formatDuration(route.duration) + " (by car)</p>" +
        '<p class="result-line"><b>Straight-line Distance:</b> ' + formatKm(straight) + "</p>" +
        '<p class="tag-note">Route from the public OSRM demo server. Times are estimates and this is not turn-by-turn navigation.</p>'
      );
    } catch (err) {
      showStatus("Could not get the route: " + err.message + " The straight-line distance is still available.", "error");
    } finally {
      busy.route = false;
      btnRoute.disabled = false;
    }
  }

  // ---------------------------------------------------------------
  // 11. SEARCH
  // ---------------------------------------------------------------
  function runSearch() {
    const text = searchInput.value.trim().toLowerCase();
    searchResults.innerHTML = "";
    if (!text) return;

    if (!hospitalsLoaded) {
      searchResults.innerHTML = '<li class="empty">Hospitals are still loading…</li>';
      return;
    }
    const matches = hospitals.filter(function (h) {
      return h.name && h.name.toLowerCase().includes(text);
    });
    if (matches.length === 0) {
      searchResults.innerHTML = '<li class="empty">No matching hospital in the loaded data.</li>';
      return;
    }
    matches.forEach(function (h) {
      const li = document.createElement("li");
      li.textContent = h.name;
      li.addEventListener("click", function () {
        searchResults.innerHTML = "";
        searchInput.value = h.name;
        selectHospital(h);
        map.setView([h.lat, h.lon], 17);
        if (h.marker) h.marker.openPopup();
      });
      searchResults.appendChild(li);
    });
  }
  searchInput.addEventListener("input", runSearch);

  // ---------------------------------------------------------------
  // 12. BUTTONS
  // ---------------------------------------------------------------
  btnLocate.addEventListener("click", function () { useMyLocation(true); });

  btnNearest.addEventListener("click", function () {
    btnNearest.disabled = true;
    findNearest().finally(function () { btnNearest.disabled = false; });
  });

  btnRoute.addEventListener("click", showRoute);

  btnClearRoute.addEventListener("click", function () {
    clearRoute();
    clearNearestLine();
    selectedHospital = null;
    btnRoute.disabled = true;
    renderMarkers();
    showResult('<p class="hint">Route cleared.</p>');
  });

  btnReset.addEventListener("click", function () {
    map.closePopup();
    map.setView(CENTER, DEFAULT_ZOOM);
  });

  filterSelect.addEventListener("change", renderMarkers);

  // ---------------------------------------------------------------
  // 13. START
  // ---------------------------------------------------------------
  loadHospitals();
});
