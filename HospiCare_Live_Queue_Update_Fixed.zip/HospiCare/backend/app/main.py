"""HospiCare API starter. Configure DATABASE_URL and SECRET_KEY before running."""
import os
from datetime import datetime, timedelta, timezone
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from passlib.context import CryptContext
from pydantic import BaseModel, EmailStr
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

DATABASE_URL=os.getenv("DATABASE_URL", "postgresql+psycopg://postgres:password@localhost:5432/hospicare")
SECRET_KEY=os.getenv("SECRET_KEY", "CHANGE_THIS_TO_A_LONG_RANDOM_SECRET_BEFORE_USE")
ALGORITHM="HS256"
engine=create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal=sessionmaker(bind=engine, autoflush=False, autocommit=False)
app=FastAPI(title="HospiCare API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("CORS_ORIGINS","http://127.0.0.1:5500,http://localhost:5500").split(","), allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
pwd=CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2=OAuth2PasswordBearer(tokenUrl="/auth/login")
class Login(BaseModel):
    email: EmailStr
    password: str
    role: str
class RegisterPatient(BaseModel):
    name: str
    email: EmailStr
    password: str
    phone: str
class TokenOut(BaseModel):
    access_token: str
    token_type: str="bearer"

def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()
def issue_token(user_id: int, role: str, hospital_id: int|None=None):
    payload={"sub":str(user_id),"role":role,"hospital_id":hospital_id,"exp":datetime.now(timezone.utc)+timedelta(hours=2)}
    return jwt.encode(payload,SECRET_KEY,algorithm=ALGORITHM)
def current_user(token: str=Depends(oauth2)):
    try: return jwt.decode(token,SECRET_KEY,algorithms=[ALGORITHM])
    except JWTError: raise HTTPException(401,"Invalid or expired session")
@app.get("/health")
def health(): return {"status":"ok","service":"HospiCare API"}
@app.post("/auth/register/patient")
def register_patient(data:RegisterPatient, s=Depends(db)):
    if len(data.password)<10: raise HTTPException(400,"Password must be at least 10 characters")
    exists=s.execute(text("SELECT id FROM users WHERE email=:e"),{"e":data.email}).first()
    if exists: raise HTTPException(409,"Account already exists")
    result=s.execute(text("INSERT INTO users(email,password_hash,role,is_active) VALUES(:e,:p,'patient',true) RETURNING id"),{"e":data.email,"p":pwd.hash(data.password)})
    uid=result.scalar_one()
    s.execute(text("INSERT INTO patients(user_id,full_name,phone) VALUES(:u,:n,:p)"),{"u":uid,"n":data.name,"p":data.phone})
    s.commit(); return {"message":"Patient account created. Verify contact details before production use."}
@app.post("/auth/login",response_model=TokenOut)
def login(data:Login,s=Depends(db)):
    if data.role not in ("patient","doctor","manager"): raise HTTPException(400,"Invalid role")
    row=s.execute(text("SELECT id,password_hash,role,is_active,hospital_id FROM users WHERE email=:e"),{"e":data.email}).mappings().first()
    if not row or not row["is_active"] or row["role"]!=data.role or not pwd.verify(data.password,row["password_hash"]): raise HTTPException(401,"Invalid credentials or role")
    return {"access_token":issue_token(row["id"],row["role"],row["hospital_id"])}
@app.get("/me")
def me(u=Depends(current_user)): return {"user_id":u["sub"],"role":u["role"],"hospital_id":u.get("hospital_id")}
@app.get("/manager/summary")
def manager_summary(u=Depends(current_user),s=Depends(db)):
    if u["role"]!="manager" or not u.get("hospital_id"): raise HTTPException(403,"Hospital manager access required")
    # Hospital scope is applied in every query; extend with validated date filters as needed.
    row=s.execute(text("SELECT COUNT(*) AS appointments FROM appointments WHERE hospital_id=:h"),{"h":u["hospital_id"]}).mappings().first()
    return dict(row)
@app.get("/doctor/appointments")
def doctor_appointments(u=Depends(current_user),s=Depends(db)):
    if u["role"]!="doctor": raise HTTPException(403,"Doctor access required")
    return [dict(r) for r in s.execute(text("SELECT id,appointment_at,status,patient_id FROM appointments WHERE doctor_user_id=:u ORDER BY appointment_at"),{"u":int(u["sub"])}).mappings()]
