# HospiCare FastAPI backend starter

This is a starter backend, not a finished production healthcare system. It includes basic JWT login, patient registration, password hashing and example role-scoped endpoints. Complete the remaining APIs, staff approval, email/OTP verification, consent, audit coverage, rate limiting, file scanning, backups and security review before real use.

## Setup
1. Install PostgreSQL and create database `hospicare`.
2. Run `schema.sql` against the database.
3. Create a virtual environment and install `pip install -r requirements.txt`.
4. Set environment variables `DATABASE_URL` and a strong random `SECRET_KEY`. Never use the example/default secret in deployment.
5. Run `uvicorn app.main:app --reload`.
6. API docs: `http://127.0.0.1:8000/docs`.

The existing static HTML login is a visual/demo flow only and is not yet wired to this API. Replace its demo handler with API calls and store tokens using a secure, HttpOnly cookie strategy before production. Do not store real patient information in the demo frontend.
