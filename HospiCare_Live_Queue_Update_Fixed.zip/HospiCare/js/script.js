const KEY="hospicare_demo_bookings";
const read=()=>{try{return JSON.parse(localStorage.getItem(KEY)||"[]")}catch{return[]}};
const write=x=>localStorage.setItem(KEY,JSON.stringify(x));
const USERS_KEY="hospicare_demo_users",CURRENT_KEY="hospicare_current_user";
const readUsers=()=>{try{return JSON.parse(localStorage.getItem(USERS_KEY)||"{}")}catch(e){return{}}};
const activeUser=()=>{try{return JSON.parse(localStorage.getItem(CURRENT_KEY)||"null")}catch(e){return null}};
const registerPatient=(email,password,profile)=>{email=String(email||"").trim().toLowerCase();if(!email||!password||password.length<6)throw Error("Enter a valid email and password of at least 6 characters.");const users=readUsers();if(users[email])throw Error("Account already exists. Please sign in.");users[email]={email,password,profile:profile||{}};localStorage.setItem(USERS_KEY,JSON.stringify(users));localStorage.setItem(CURRENT_KEY,JSON.stringify({email,role:"patient"}));return email};
const safe=s=>String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const $=(s,r=document)=>r.querySelector(s);

document.addEventListener("DOMContentLoaded",()=>{
 /* ---------- booking flow ---------- */
 const form=$("#appointment-form");
 if(form){
  const panels=[...form.querySelectorAll("[data-step]")],total=panels.length;
  const items=[...document.querySelectorAll(".steps li")];
  const err=$("#step-error"),back=$("#back-btn"),next=$("#next-btn"),bar=$(".mprog i"),mtxt=$(".mprog p");
  const names=["Hospital","Doctor","Date and time","Patient details"];
  const params=new URLSearchParams(location.search);
  [["hospital"],["doctor"]].forEach(([n])=>{const v=params.get(n);if(v){const r=[...form.querySelectorAll(`input[name=${n}]`)].find(x=>x.value===v);if(r)r.checked=true}});
  let step=form.hospital.value?(form.doctor.value?3:2):1;

  /* date tabs + time slots */
  const dn=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],full=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
        mn=["January","February","March","April","May","June","July","August","September","October","November","December"];
  const iso=d=>d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
  const days=[...Array(7)].map((_,i)=>{const d=new Date();d.setDate(d.getDate()+i);return d});
  const fmt=m=>{const h=Math.floor(m/60),mm=String(m%60).padStart(2,"0");return String(h%12||12).padStart(2,"0")+":"+mm+(h<12?" AM":" PM")};
  const times=[...Array(16)].map((_,i)=>fmt(540+i*30));
  let day=0;
  const dayBox=$("#days"),slotBox=$("#slots"),sum=$("#sel");
  const draw=()=>{
   dayBox.innerHTML="";slotBox.innerHTML="";
   days.forEach((d,i)=>{const b=document.createElement("button");b.type="button";b.className="day";b.setAttribute("role","tab");b.setAttribute("aria-selected",i===day);
    b.innerHTML=`<small>${i===0?"Today":i===1?"Tomorrow":dn[d.getDay()]}</small><b>${d.getDate()}</b>`;
    b.onclick=()=>{day=i;form.date.value=iso(d);if(isBooked(form.time.value))form.time.value="";draw()};dayBox.appendChild(b)});
   times.forEach((t,i)=>{const b=document.createElement("button");b.type="button";b.className="slot";b.textContent=t;
    const off=isBooked(t);if(off){b.disabled=true;b.setAttribute("aria-label",t+", booked")}
    b.setAttribute("aria-pressed",String(t===form.time.value&&!off));
    b.onclick=()=>{form.time.value=t;draw()};slotBox.appendChild(b)});
   const d=days[day];sum.textContent=form.time.value?`${full[d.getDay()]}, ${mn[d.getMonth()]} ${d.getDate()}, ${form.time.value}`:"Choose a time slot";
  };
  const isBooked=t=>times.indexOf(t)>-1&&(times.indexOf(t)*3+day*5)%7===0;
  form.date.value=iso(days[0]);draw();
  const accEmail=$("#booking-account-email"),accPass=$("#booking-account-password"),accStatus=$("#booking-account-status");
  const fillAccount=()=>{const u=activeUser();if(u?.role==="patient"){if(accEmail)accEmail.value=u.email;const profile=readUsers()[u.email]?.profile||{};if(form.name&&!form.name.value)form.name.value=profile.name||"";if(form.phone&&!form.phone.value)form.phone.value=profile.phone||"";if(form.age&&!form.age.value)form.age.value=profile.age||"";if(accStatus)accStatus.textContent="Signed in as "+u.email;}};
  fillAccount();
  $("#booking-account-create")?.addEventListener("click",()=>{try{const email=registerPatient(accEmail.value,accPass.value,{name:form.name.value,phone:form.phone.value,age:form.age.value});accStatus.textContent="Account created. Signed in as "+email;}catch(e){accStatus.textContent=e.message;}});
  $("#booking-account-login")?.addEventListener("click",()=>{const email=accEmail.value.trim().toLowerCase(),u=readUsers()[email];if(u&&u.password===accPass.value){localStorage.setItem(CURRENT_KEY,JSON.stringify({email,role:"patient"}));accStatus.textContent="Signed in as "+email;fillAccount();}else accStatus.textContent="Account not found or password incorrect.";});

  const valid=()=>{
   if(step===1&&!form.hospital.value)return "Choose a hospital to continue.";
   if(step===2&&!form.doctor.value)return "Choose a doctor to continue.";
   if(step===3&&!form.time.value)return "Choose a time slot to continue.";
   return "";
  };
  const show=()=>{
   panels.forEach((p,i)=>p.hidden=i+1!==step);
   items.forEach((li,i)=>{li.classList.toggle("done",i+1<step);li.classList.toggle("cur",i+1===step);const d=li.querySelector(".dot");d.textContent=i+1<step?"✓":i+1;if(i+1===step)li.setAttribute("aria-current","step");else li.removeAttribute("aria-current")});
   if(bar)bar.style.width=(step/(total+1))*100+"%";if(mtxt)mtxt.textContent=`Step ${step} of ${total+1} · ${names[step-1]}`;
   back.hidden=step===1;next.textContent=step===total?"Confirm appointment":"Next";
   err.hidden=true;
  };
  next.addEventListener("click",()=>{
   const m=valid();if(m){err.textContent=m;err.hidden=false;return}
   if(step<total){step++;show();window.scrollTo({top:0})}else form.requestSubmit();
  });
  back.addEventListener("click",()=>{if(step>1){step--;show()}});
  form.querySelectorAll("input[type=radio]").forEach(r=>r.addEventListener("change",()=>{err.hidden=true}));
  const date=form.date;
  form.addEventListener("submit",e=>{e.preventDefault();if(!form.reportValidity())return;
   const data=Object.fromEntries(new FormData(form).entries()),all=read(),u=activeUser();
   data.token="HC-"+String(all.length+1).padStart(3,"0");data.status="Demo booking";data.patientEmail=u?.email||"";data.createdAt=new Date().toISOString();
   if(u?.email){const users=readUsers();users[u.email].profile={...(users[u.email].profile||{}),name:data.name,phone:data.phone,age:data.age};localStorage.setItem(USERS_KEY,JSON.stringify(users));}
   all.unshift(data);write(all);localStorage.setItem("hospicare_latest_token",JSON.stringify(data));location.href="token.html";
  });
  show();
 }

 /* ---------- token / queue / dashboard ---------- */
 const latest=read()[0];
 const token=$("#token-number");
 if(token&&latest){token.textContent=latest.token;$("#token-details").innerHTML=`<p><b>${safe(latest.name)}</b> · Patient</p><p>${safe(latest.hospital)}</p><p>${safe(latest.doctor)}</p><p>${safe(latest.date)} · ${safe(latest.time)}</p>`;}
 if($("#queue-token")){$("#queue-token").textContent=latest?latest.token:"HC-001";$("#ahead").textContent=latest?"3":"4";$("#wait").textContent=latest?"30 min":"40 min";if(latest)$("#queue-message").textContent=`${latest.name}, your demo token ${latest.token} is registered. Queue details are simulated.`;}
 if($("#history")){
  const user=activeUser();
  const all=user?.role==="patient" ? read().filter(a=>String(a.patientEmail||"").toLowerCase()===String(user.email||"").toLowerCase()) : [];
  const today=new Date();today.setHours(0,0,0,0);
  const upcoming=all.filter(a=>{const d=new Date((a.date||"")+"T00:00:00");return !Number.isNaN(d.getTime())&&d>=today;});
  $("#total").textContent=all.length;
  $("#upcoming").textContent=upcoming.length;
  $("#latest").textContent=all[0]?.token||"—";
  if(all.length){
   $("#history").innerHTML=all.map(a=>`<div class="history-item"><div><b>${safe(a.hospital)}</b><small>${safe(a.doctor)} · ${safe(a.date)} at ${safe(a.time)}</small></div><b>${safe(a.token)}</b></div>`).join("");
  }else{
   $("#history").innerHTML='No appointments yet. <a href="appointment.html" style="color:var(--primary-dark);font-weight:700;text-decoration:underline">Book your first visit</a>.';
  }
 }

 /* ---------- search + filter ---------- */
 function search(inputId,filterId,gridId){const input=document.getElementById(inputId),filter=document.getElementById(filterId),grid=document.getElementById(gridId);if(!input||!grid)return;
  const update=()=>[...grid.children].forEach(card=>{const text=card.textContent.toLowerCase(),q=input.value.toLowerCase(),f=filter?.value||"all";card.hidden=!(text.includes(q)&&(f==="all"||text.includes(f.toLowerCase())))});
  input.addEventListener("input",update);filter?.addEventListener("change",update);}
 search("hospital-search","hospital-filter","hospital-grid");search("doctor-search","doctor-filter","doctor-grid");
});

/* ---------- shared sidebar toggle (all pages) ---------- */
(function(){
 const root=document.documentElement,btn=document.getElementById("menu-toggle"),side=document.getElementById("sidebar");if(!btn||!side)return;
 const mq=matchMedia("(max-width:1000px)"),K="hospicare_sidebar";
 const sync=()=>{const open=mq.matches?root.classList.contains("menu-open"):!root.classList.contains("sb-collapsed");btn.setAttribute("aria-expanded",String(open));btn.setAttribute("aria-label",open?"Collapse menu":"Expand menu")};
 btn.addEventListener("click",()=>{if(mq.matches)root.classList.toggle("menu-open");else{const c=root.classList.toggle("sb-collapsed");try{localStorage.setItem(K,c?"collapsed":"expanded")}catch(e){}}sync()});
 mq.addEventListener("change",()=>{root.classList.remove("menu-open");if(mq.matches)root.classList.remove("sb-collapsed");else try{if(localStorage.getItem(K)==="collapsed")root.classList.add("sb-collapsed")}catch(e){}sync()});
 sync();
 const tip=document.createElement("div");tip.className="tip";tip.setAttribute("role","tooltip");document.body.appendChild(tip);
 const show=e=>{if(!root.classList.contains("sb-collapsed")||mq.matches)return;const t=e.target.closest("[data-tip]");if(!t)return;tip.textContent=t.dataset.tip;const r=t.getBoundingClientRect();tip.style.left=r.right+10+"px";tip.style.top=r.top+r.height/2+"px";tip.classList.add("on")};
 const hide=()=>tip.classList.remove("on");
 side.addEventListener("mouseover",show);side.addEventListener("focusin",show);side.addEventListener("mouseout",hide);side.addEventListener("focusout",hide);
 btn.addEventListener("click",hide);
})();

/* Offline QR booking notice */
document.addEventListener("DOMContentLoaded",()=>{
 const qrNotice=document.getElementById("offline-qr-notice");
 if(qrNotice && new URLSearchParams(location.search).get("source")==="offline-qr") qrNotice.hidden=false;
});


// ---------- homepage doctor spotlight carousel ----------
document.addEventListener("DOMContentLoaded",()=>{
 const name=document.getElementById("spotlight-name");
 if(!name)return;
 const doctors=[
  {name:"Dr. Shrikant Kurhade",specialty:"Laparoscopic / GI Surgery",hospital:"KK Multispeciality Hospital",url:"doctor-booking.html?doctor=dr-shrikant-kurhade",note:"Public profile listing · verify current details with the provider."},
  {name:"Dr. Mahavir Bagrecha",specialty:"Pulmonology",hospital:"KK Multispeciality Hospital",url:"doctor-booking.html?doctor=dr-mahavir-bagrecha",note:"Public profile listing · verify current details with the provider."},
  {name:"Dr. Tushar Chaudhary",specialty:"Orthopaedics",hospital:"KK Multispeciality Hospital",url:"doctor-booking.html?doctor=dr-tushar-chaudhary",note:"Public profile listing · verify current details with the provider."},
  {name:"Dr. Varsha Kurhade",specialty:"Anaesthesiology / Pain Medicine",hospital:"KK Multispeciality Hospital",url:"doctor-booking.html?doctor=dr-varsha-kurhade",note:"Public profile listing · verify current details with the provider."},
  {name:"Dr. Prashant Rokade",specialty:"Speciality to be confirmed",hospital:"Amrut Hospital and Research Center",url:"doctor-booking.html?doctor=dr-prashant-rokade",note:"Speciality and current affiliation require provider confirmation."},
  {name:"Dr. Pratik D. Ajagekar",specialty:"Speciality to be confirmed",hospital:"Amrut Hospital and Research Center",url:"doctor-booking.html?doctor=dr-pratik-ajagekar",note:"Speciality and current affiliation require provider confirmation."},
  {name:"Dr. Ramnath Raut",specialty:"Speciality to be confirmed",hospital:"Amrut Hospital and Research Center",url:"doctor-booking.html?doctor=dr-ramnath-raut",note:"Speciality and current affiliation require provider confirmation."}
 ];
 const specialty=document.getElementById("spotlight-specialty");
 const hospital=document.getElementById("spotlight-hospital");
 const note=document.getElementById("spotlight-note");
 const book=document.getElementById("spotlight-book");
 const photo=document.getElementById("spotlight-photo");
 const portraits=[
  "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=500&h=700&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=500&h=700&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=500&h=700&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=500&h=700&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=500&h=700&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1622902046580-2b47f47f5471?w=500&h=700&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1612531386530-97286d97c2d2?w=500&h=700&fit=crop&crop=faces"
 ];
 let current=0,timer=null,renderVersion=0;
 const render=()=>{
  const version=++renderVersion,d=doctors[current],url=portraits[current];
  // Keep the current complete slide visible until its matching portrait has loaded.
  const commit=(loadedUrl)=>{
   if(version!==renderVersion)return;
   name.textContent=d.name; specialty.textContent=d.specialty; hospital.textContent=d.hospital;
   note.textContent=d.note; book.href=d.url;
   if(loadedUrl){photo.src=loadedUrl;photo.alt=`Stock doctor portrait for ${d.name}; not a verified likeness`;}
   const card=document.querySelector(".doctor-spotlight");
   if(card){card.classList.remove("spotlight-ready");void card.offsetWidth;card.classList.add("spotlight-ready");}
  };
  const preload=new Image();
  preload.onload=()=>commit(url);
  preload.onerror=()=>commit("assets/doctor-profile-illustration.svg");
  preload.src=url;
 };
 const restart=()=>{if(timer)clearInterval(timer);timer=setInterval(()=>{current=(current+1)%doctors.length;render()},3000)};
 const carousel=document.querySelector(".doctor-spotlight");
 if(!carousel)return;
 carousel.addEventListener("mouseenter",()=>{if(timer)clearInterval(timer)});
 carousel.addEventListener("mouseleave",restart);
 carousel.addEventListener("focusin",()=>{if(timer)clearInterval(timer)});
 carousel.addEventListener("focusout",restart);
 document.addEventListener("visibilitychange",()=>{if(document.hidden){if(timer)clearInterval(timer)}else restart()});
 render();restart();
});

// ---------- patient queue: alert two tokens before the patient's turn ----------
document.addEventListener("DOMContentLoaded",()=>{
 const tokenEl=document.getElementById("queue-token");
 if(!tokenEl)return;
 const message=document.getElementById("queue-message");
 const servingEl=document.getElementById("now-serving-token");
 const status=document.getElementById("queue-status");
 const enable=document.getElementById("enable-queue-alerts");
 const KEY="hospicare_now_serving";
 const readBookings=()=>{try{return JSON.parse(localStorage.getItem("hospicare_demo_bookings")||"[]")}catch(e){return[]}};
 const user=(()=>{try{return JSON.parse(localStorage.getItem("hospicare_current_user")||"null")}catch(e){return null}})();
 const bookings=readBookings();
 const mine=bookings.filter(b=>user&&user.role==="patient"&&String(b.patientEmail||"").toLowerCase()===String(user.email||"").toLowerCase());
 const appointment=mine[0]||bookings[0]||null;
 const tokenText=appointment?.token||"";
 const tokenNumber=Number((tokenText.match(/(\d+)/)||[])[1]||0);
 tokenEl.textContent=tokenText||"—";
 if(!appointment){
  if(message)message.textContent="No appointment found. Book an appointment to see your queue status.";
  if(status)status.textContent="Your queue updates will appear here after booking.";
  if(enable)enable.disabled=true;
  return;
 }
 if(message)message.textContent=`${appointment.name||"Patient"}, your token ${tokenText} is registered for ${appointment.hospital||"your selected hospital"}.`;
 let permission=typeof Notification!=="undefined"&&Notification.permission==="granted";
 let alerted=false;
 const readServing=()=>Number(localStorage.getItem(KEY)||"0");
 const update=()=>{
  const serving=readServing();
  if(servingEl)servingEl.textContent=serving?`HC-${String(serving).padStart(3,"0")}`:"Not updated yet";
  if(!serving){if(status)status.textContent="Waiting for the hospital to update the current token.";return;}
  const difference=tokenNumber-serving;
  if(difference<=0){
   if(status)status.textContent="Your token is being called. Please proceed to the consultation area.";
   if(permission&&!alerted){new Notification("HospiCare: Your turn is now",{body:"Please proceed to the consultation area."});alerted=true;}
  }else if(difference<=2){
   if(status)status.textContent=`Your turn is approaching. ${difference} token${difference===1?"":"s"} before yours. Please come to the hospital now.`;
   if(permission&&!alerted){new Notification("HospiCare: Please come to the hospital",{body:`Your token ${tokenText} is approaching. The hospital is serving HC-${String(serving).padStart(3,"0")}.`});alerted=true;}
  }else{
   if(status)status.textContent=`The hospital is serving HC-${String(serving).padStart(3,"0")}. ${difference} tokens before yours.`;
  }
 };
 if(enable){
  enable.addEventListener("click",async()=>{
   if(!("Notification"in window)){if(status)status.textContent="This browser does not support notifications.";return;}
   const result=await Notification.requestPermission();
   permission=result==="granted";
   if(status)status.textContent=permission?"Notifications enabled. We'll alert you when two tokens remain.":"Notifications were not enabled. You can still see queue updates here.";
   enable.textContent=permission?"Alerts enabled":"Enable turn alerts";
   update();
  });
 }
 update();
 window.addEventListener("storage",e=>{if(e.key===KEY)update()});
 setInterval(update,5000);
});
