/* HospiCare Firebase configuration.
   Replace apiKey with the Web API key from Firebase Console > Project settings > Your apps.
   Firebase web config is not a password; secure access with Firebase Auth + Firestore Rules. */
window.HOSPICARE_FIREBASE_CONFIG = {
  apiKey: "AIzaSyDLlukGmq4-fYNhTs0R-b2hKtH55jLbmYk",
  authDomain: "hospicare-603cf.firebaseapp.com",
  projectId: "hospicare-603cf",
  storageBucket: "hospicare-603cf.firebasestorage.app",
  messagingSenderId: "179219266022",
  appId: "1:179219266022:web:42d09c7f0746a35d6ebe27"
};
