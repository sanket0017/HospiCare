/* Firebase-backed HospiCare dashboards, live queue and doctor availability. */
(() => {
  const $ = (id) => document.getElementById(id);
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const msg = (id, text, bad=false) => { const e=$(id); if(e){e.textContent=text;e.style.color=bad?'#b42318':'#087f73';} };
  const ready = () => window.HC_FIREBASE_READY && window.hcAuth && window.hcDb;
  const today = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const dateInput=$('doctor-queue-date');
  if(dateInput && !dateInput.value) dateInput.value=today();

  if(!ready()) { if($('doctor-live-appointments')||$('manager-live-appointments')) msg('queue-control-status','Firebase is not ready. Check your internet connection and Firebase configuration.',true); return; }

  hcAuth.onAuthStateChanged(async user => {
    const isDoctorPage=!!$('doctor-live-appointments') || !!$('save-availability');
    const isManagerPage=!!$('manager-live-appointments');
    const isPatientPage=!!$('my-count');
    if(!user) {
      if(isDoctorPage||isManagerPage||isPatientPage) location.replace('login.html');
      return;
    }
    let profile;
    try {
      const ps=await hcDb.collection('users').doc(user.uid).get();
      if(!ps.exists) throw new Error('Your HospiCare profile is missing. Contact the administrator.');
      profile=ps.data();
      if(isDoctorPage && profile.role!=='doctor') throw new Error('This account is not assigned as a doctor.');
      if(isManagerPage && !['manager','hospital_manager'].includes(profile.role)) throw new Error('This account is not assigned as a hospital manager.');
      if(isPatientPage && profile.role!=='patient') throw new Error('Please sign in with a patient account.');
    } catch(e) {
      if(isDoctorPage) msg('queue-control-status',e.message,true);
      if(isManagerPage) { const el=$('manager-live-appointments'); if(el)el.textContent=e.message; }
      if(isPatientPage) { const el=$('my-profile'); if(el)el.textContent=e.message; }
      return;
    }

    if(isDoctorPage) {
      const doctorId=profile.doctorId;
      if(!doctorId) { msg('queue-control-status','Your profile is missing doctorId.',true); return; }
      const doctorName=profile.name||'Doctor';
      document.querySelector('.dashhead h1')?.replaceChildren(document.createTextNode(`Good day, ${doctorName}`));
      const availRef=hcDb.collection('doctorAvailability').doc(doctorId);
      try {
        const av=await availRef.get();
        if(av.exists) {
          const a=av.data();
          [...($('availability-days')?.options||[])].forEach(o=>o.selected=(a.availableDays||[]).includes(Number(o.value)));
          if($('availability-start'))$('availability-start').value=a.startTime||'09:00';
          if($('availability-end'))$('availability-end').value=a.endTime||'17:00';
          if($('availability-duration'))$('availability-duration').value=String(a.slotMinutes||30);
        }
      } catch(e) { msg('availability-status','Could not load availability: '+e.message,true); }
      $('save-availability')?.addEventListener('click',async()=>{
        try {
          const days=[...$('availability-days').selectedOptions].map(o=>Number(o.value));
          const startTime=$('availability-start').value,endTime=$('availability-end').value,slotMinutes=Number($('availability-duration').value);
          if(!days.length||!startTime||!endTime||startTime>=endTime) throw new Error('Choose at least one day and a valid start/end time.');
          await availRef.set({doctorId,hospitalId:profile.hospitalId,availableDays:days,startTime,endTime,slotMinutes,enabled:true,updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
          msg('availability-status','Availability saved. Patients on other devices can now see these hours.');
        } catch(e) { msg('availability-status',e.message,true); }
      });
      let queueUnsubscribe=null;
      let watchedQueueRef=null;
      const watchQueue=()=>{
        const d=dateInput?.value||today(), qid=doctorId+'_'+d;
        if(queueUnsubscribe){queueUnsubscribe();queueUnsubscribe=null;}
        watchedQueueRef=hcDb.collection('queues').doc(qid);
        queueUnsubscribe=watchedQueueRef.onSnapshot(qs=>{
          if($('current-serving-input')) $('current-serving-input').value=qs.exists?Number(qs.data().currentServingToken||0):0;
          if(!qs.exists) msg('queue-control-status','No queue exists for this date yet. It will be created with the first booking.');
          else {
            const q=qs.data();
            msg('queue-control-status',`Live queue · HC-${String(Number(q.currentServingToken||0)).padStart(3,'0')} being served · ${Number(q.lastIssuedToken||0)} tokens issued · ${q.status||'active'}`);
          }
        },e=>msg('queue-control-status','Queue read failed: '+e.message,true));
      };
      dateInput?.addEventListener('change',watchQueue);
      watchQueue();
      $('save-current-serving')?.addEventListener('click',async()=>{
        try {
          const value=Number($('current-serving-input').value);
          if(!Number.isInteger(value)||value<0) throw new Error('Enter a valid token number (0 or higher).');
          const qs=await watchedQueueRef.get();
          if(!qs.exists) throw new Error('No queue exists for this date. Book an appointment first.');
          const q=qs.data();
          if(value>Number(q.lastIssuedToken||0)) throw new Error(`Only tokens 0 to ${Number(q.lastIssuedToken||0)} have been issued.`);
          await watchedQueueRef.update({currentServingToken:value,updatedAt:firebase.firestore.FieldValue.serverTimestamp()});
          msg('queue-control-status','Queue updated successfully. Patient queue pages will update automatically.');
        } catch(e) { msg('queue-control-status',e.message,true); }
      });
      
      const apRef=hcDb.collection('appointments').where('doctorId','==',doctorId);
      apRef.onSnapshot(snap=>{
        const rows=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(a.appointmentDate||'').localeCompare(b.appointmentDate||'')||(a.tokenNumber||0)-(b.tokenNumber||0));
        const todayRows=rows.filter(a=>a.appointmentDate===today());
        const stats=document.querySelectorAll('.stats .stat strong');
        if(stats.length>=6){stats[0].textContent=todayRows.length;stats[1].textContent=new Set(rows.map(a=>a.patientId)).size;stats[2].textContent='₹0';stats[3].textContent=rows.filter(a=>a.status==='booked').length;stats[4].textContent=rows.filter(a=>a.status==='completed').length;stats[5].textContent=rows.filter(a=>a.status==='cancelled').length;}
        const el=$('doctor-live-appointments');
        if(el)el.innerHTML=rows.length?rows.map(a=>`<p><b>${esc(a.patientName)}</b> · ${esc(a.appointmentDate)} ${esc(a.appointmentTime)} · ${esc(a.token||'')} · ${esc(a.status)}</p>`).join(''):'No appointments yet.';
        const slots=document.querySelector('.dashgrid .panel');
        if(slots && slots.querySelector('h2')?.textContent.includes('Today')) slots.innerHTML='<h2>Today’s booked slots</h2>'+(todayRows.length?todayRows.map(a=>`<p><b>${esc(a.patientName)}</b> · ${esc(a.appointmentTime)} · ${esc(a.token||'')}</p>`).join(''):'<p class="muted">No appointments booked for today.</p>');
      },e=>msg('queue-control-status','Live appointments error: '+e.message,true));
    }

    if(isManagerPage) {
      const hospitalId=profile.hospitalId;
      if(!hospitalId){msg('manager-live-appointments','Your manager profile is missing hospitalId.',true);return;}
      hcDb.collection('appointments').where('hospitalId','==',hospitalId).onSnapshot(snap=>{
        const rows=snap.docs.map(d=>({id:d.id,...d.data()}));
        const stats=document.querySelectorAll('.stats .stat strong');
        if(stats.length>=7){stats[0].textContent=rows.length;stats[1].textContent=new Set(rows.map(a=>a.patientId)).size;stats[2].textContent='1';stats[3].textContent='1';stats[4].textContent='₹0';stats[5].textContent='₹0';stats[6].textContent=rows.filter(a=>a.status==='booked').length;}
        const wrap=$('manager-live-appointments');
        if(wrap)wrap.innerHTML=rows.length?rows.map(a=>`<p><b>${esc(a.patientName)}</b> · ${esc(a.doctor)} · ${esc(a.appointmentDate)} ${esc(a.appointmentTime)} · ${esc(a.token||'')} · ${esc(a.status)}</p>`).join(''):'No appointments yet.';
        if($('manager-doctor-count'))$('manager-doctor-count').textContent=rows.filter(a=>a.doctorId==='doctor_001').length;
        if($('manager-queue-count'))$('manager-queue-count').textContent=rows.filter(a=>a.status==='booked').length+' appointments waiting';
        if($('manager-doctor-summary'))$('manager-doctor-summary').innerHTML=`<p>Dr. Shrikant Kurhade: <b>${rows.filter(a=>a.doctorId==='doctor_001').length} appointments</b></p>`;
      },e=>{if($('manager-live-appointments'))$('manager-live-appointments').textContent='Live data error: '+e.message;});
    }

    if(isPatientPage) {
      hcDb.collection('appointments').where('patientId','==',user.uid).onSnapshot(snap=>{
        const rows=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.appointmentDate||'').localeCompare(a.appointmentDate||''));
        if($('my-count'))$('my-count').textContent=rows.length;
        if($('my-upcoming'))$('my-upcoming').textContent=rows.filter(a=>a.status==='booked').length;
        if($('my-token'))$('my-token').textContent=rows[0]?.token||'—';
        if($('my-appointments'))$('my-appointments').innerHTML=rows.length?rows.map(a=>`<p><b>${esc(a.doctor)}</b> · ${esc(a.hospital)} · ${esc(a.appointmentDate)} ${esc(a.appointmentTime)} · ${esc(a.token||'')}</p>`).join(''):'No saved appointments yet.';
        if($('patient-upcoming-rows'))$('patient-upcoming-rows').innerHTML=rows.length?rows.map(a=>`<tr><td>${esc(a.doctor)}</td><td>${esc(a.appointmentDate)}</td><td>${esc(a.status)}</td></tr>`).join(''):'<tr><td colspan="3">No upcoming appointments for this account.</td></tr>';
      },e=>msg('my-profile','Could not load appointments: '+e.message,true));
      hcDb.collection('users').doc(user.uid).get().then(s=>{
        const p=s.exists?s.data():{};
        if($('my-profile'))$('my-profile').innerHTML=`<p><b>Name:</b> ${esc(p.name||user.displayName||'Patient')}</p><p><b>Email:</b> ${esc(user.email||'')}</p><p><b>Mobile:</b> ${esc(p.phone||'Not provided')}</p>`;
      }).catch(e=>msg('my-profile',e.message,true));
    }
  });

  // Patient booking page: Firestore availability and booked-slot state override static sample slots.
  if($('appointment-form')) {
    const form=$('appointment-form'), doctorId=form.querySelector('[name="doctorId"]')?.value||'doctor_001';
    const slots=$('slots'), date=form.querySelector('[name="date"]');
    const refreshSlots=async()=>{
      if(!ready()||!slots||!date?.value)return;
      try {
        const avs=await hcDb.collection('doctorAvailability').doc(doctorId).get();
        if(!avs.exists){slots.innerHTML='<p class="muted">This doctor has not published appointment availability yet.</p>';return;}
        const av=avs.data(), day=new Date(date.value+'T12:00:00').getDay();
        const valid=(av.enabled!==false)&&(av.availableDays||[]).includes(day);
        const toMin=v=>{const m=String(v||'').match(/^(\d{2}):(\d{2})$/);return m?Number(m[1])*60+Number(m[2]):-1;};
        const start=toMin(av.startTime),end=toMin(av.endTime),step=Math.max(10,Number(av.slotMinutes||30));
        if(!valid){slots.innerHTML='<p class="muted">Doctor is not available on this day.</p>';return;}
        const booked=await hcDb.collection('slotLocks').where('doctorId','==',doctorId).get();
        const locked=new Set(booked.docs.map(d=>d.data()).filter(x=>x.appointmentDate===date.value).map(x=>x.appointmentTime));
        slots.innerHTML='';
        const fmt=m=>`${String(Math.floor(m/60)%12||12).padStart(2,'0')}:${String(m%60).padStart(2,'0')} ${m<720?'AM':'PM'}`;
        for(let t=start;t<end;t+=step){
          const label=fmt(t),b=document.createElement('button');b.type='button';b.className='slot';b.textContent=label;
          const taken=locked.has(label);b.disabled=taken;b.setAttribute('aria-pressed','false');
          if(taken)b.title='Already booked';
          b.addEventListener('click',()=>{form.time.value=label;slots.querySelectorAll('.slot').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));const sel=$('sel');if(sel)sel.textContent=label;});
          slots.appendChild(b);
        }
      } catch(e) { slots.innerHTML=`<p class="muted">Could not load availability: ${esc(e.message)}</p>`; }
    };
    date?.addEventListener('change',refreshSlots);
    const dayBox=$('days');
    if(dayBox && window.MutationObserver) new MutationObserver(()=>setTimeout(refreshSlots,0)).observe(dayBox,{childList:true});
    setTimeout(refreshSlots,900);
  }

  // Patient queue page subscribes to the signed-in user's most recent appointment and queue.
  if($('queue-token')) {
    hcAuth.onAuthStateChanged(async user=>{
      if(!user){msg('queue-status','Sign in to view your live queue.',true);return;}
      try{
        const snap=await hcDb.collection('appointments').where('patientId','==',user.uid).get();
        const rows=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.appointmentDate||'').localeCompare(a.appointmentDate||'')||(b.tokenNumber||0)-(a.tokenNumber||0));
        const ap=rows[0];if(!ap){msg('queue-status','No appointment found for this account.');return;}
        if($('queue-token'))$('queue-token').textContent=ap.token||'HC-'+ap.tokenNumber;
        const render=q=>{
          const current=Number(q.currentServingToken||0),ahead=Math.max(0,Number(ap.tokenNumber||0)-current-1);
          if($('now-serving-token'))$('now-serving-token').textContent=current?`Token ${current}`:'Not updated yet';
          if($('queue-people-ahead'))$('queue-people-ahead').textContent=ahead;
          if($('queue-estimated-wait'))$('queue-estimated-wait').textContent=`${ahead*Number(q.averageConsultationMinutes||10)} min`;
          if($('queue-message'))$('queue-message').textContent=ahead===0?'Your turn is next or being called.':'Please wait for your turn.';
          msg('queue-status','Live queue connected.');
        };
        hcDb.collection('queues').doc(ap.queueId).onSnapshot(s=>{if(s.exists)render(s.data());else msg('queue-status','Queue has not been initialized yet.');},e=>msg('queue-status',e.message,true));
      }catch(e){msg('queue-status','Could not load queue: '+e.message,true);}
    });
  }
})();
