/* HospiCare live queue: public aggregate only; no patient details are exposed here. */
(()=>{
 const pad=n=>'HC-'+String(Number(n)||0).padStart(3,'0');
 const el=id=>document.getElementById(id);
 const safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const today=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
 const queueRef=(doctorId,date)=>hcDb.collection('queues').doc(doctorId+'_'+date);
 document.addEventListener('DOMContentLoaded',()=>{
  const isPatientPage=!!el('queue-token');
  if(el('current-serving-input') && sessionStorage.getItem('hc_demo_role')==='doctor'){ startDemoDoctorQueue(); return; }
  if(!window.HC_FIREBASE_READY)return;
  if(isPatientPage) startPatientQueue();
  // Firebase doctor queue is managed by firebase-workflows.js. Do not attach a second handler here.
 });
 async function startPatientQueue(){
  const msg=el('queue-message'),now=el('now-serving-token'),tokenEl=el('queue-token'),status=el('queue-status');
  const set=(x)=>{if(msg)msg.textContent=x};
  const saved=(()=>{try{return JSON.parse(sessionStorage.getItem('hospicare_latest_token')||'null')}catch{return null}})();
  const query=new URLSearchParams(location.search); let appointment=saved;
  try{
   const user=await new Promise(resolve=>hcAuth.onAuthStateChanged(resolve));
   if(!appointment?.id && user){const snap=await hcDb.collection('appointments').where('patientId','==',user.uid).orderBy('createdAt','desc').limit(1).get();if(!snap.empty)appointment={id:snap.docs[0].id,...snap.docs[0].data()};}
   if(!appointment){set('Sign in and book an appointment to view your personal queue.');return;}
   const aSnap=await hcDb.collection('appointments').doc(appointment.id).get();
   if(aSnap.exists)appointment={id:aSnap.id,...aSnap.data()};
   if(!appointment.doctorId||!appointment.appointmentDate){set('This appointment does not have a linked doctor queue yet.');return;}
   const queueId=appointment.queueId||appointment.doctorId+'_'+appointment.appointmentDate;
   if(tokenEl)tokenEl.textContent=appointment.token||pad(appointment.tokenNumber);
   const qref=hcDb.collection('queues').doc(queueId);
   qref.onSnapshot(snap=>{
    if(!snap.exists){set('The hospital has not started publishing this doctor’s queue yet.');return;}
    const q=snap.data(),serving=Number(q.currentServingToken||0),mine=Number(appointment.tokenNumber||0),ahead=Math.max(0,mine-serving-1);
    if(now)now.textContent=serving?pad(serving):'Not started';
    const mins=Number(q.averageConsultationMinutes||10)*ahead;
    set(q.status==='paused'?'The doctor has temporarily paused this queue. Please wait for an update.':ahead===0?'Your turn is now. Please proceed to the hospital.':`${ahead} patient${ahead===1?'':'s'} ahead of you · estimated wait ${mins} minutes.`);
    if(el('queue-people-ahead'))el('queue-people-ahead').textContent=String(ahead);
    if(el('queue-estimated-wait'))el('queue-estimated-wait').textContent=mins+' min';
    if(q.status==='completed')set('This doctor’s queue for the selected date is completed.');
    if(Notification.permission==='granted' && ahead<=2 && ahead>=0 && !sessionStorage.getItem('hc_alert_'+appointment.id+'_'+serving)){
      new Notification('HospiCare: your turn is approaching',{body:ahead===0?'Your turn is now. Please proceed to the hospital.':`Only ${ahead} patient(s) ahead. Please get ready to visit the hospital.`});
      sessionStorage.setItem('hc_alert_'+appointment.id+'_'+serving,'1');
    }
   },err=>set('Live queue unavailable: '+err.message));
   el('enable-queue-alerts')?.addEventListener('click',async()=>{if(!('Notification'in window)){if(status)status.textContent='Browser notifications are not supported.';return;}const p=await Notification.requestPermission();if(status)status.textContent=p==='granted'?'Turn alerts enabled. Keep this page open.':'Notification permission was not granted.';});
  }catch(e){set('Could not load live queue: '+e.message);}
 }
 async function startDemoDoctorQueue(){
  const input=el('current-serving-input'),btn=el('save-current-serving'),status=el('queue-control-status');
  if(!input||!btn)return;
  const panel=input.closest('.panel');
  const date=document.createElement('input');date.type='date';date.className='input';date.id='doctor-queue-date';date.value=today();
  const label=document.createElement('label');label.className='field';label.textContent='Queue date';label.appendChild(date);panel.insertBefore(label,input.parentElement||btn);
  const queueKey=()=>`hc_demo_queue_dr-shrikant-kurhade_${date.value}`;
  const bookings=()=>{try{return JSON.parse(localStorage.getItem('hospicare_demo_bookings')||'[]').filter(a=>a.hospital==='KK Multispeciality Hospital'&&a.doctor==='Dr. Shrikant Kurhade'&&String(a.date||'').slice(0,10)===date.value&&String(a.status||'Booked').toLowerCase()!=='cancelled');}catch{return [];}};
  const read=()=>{try{return JSON.parse(localStorage.getItem(queueKey())||'{}')}catch{return {};}};
  const save=q=>localStorage.setItem(queueKey(),JSON.stringify(q));
  function refresh(){const q=read(),issued=bookings().length;input.value=Number(q.currentServingToken||0);status.textContent=`Demo live queue · ${pad(q.currentServingToken||0)} being served · ${issued} tokens issued · ${q.status||'active'}`;}
  function ensure(){const q=read();if(!('currentServingToken'in q))save({currentServingToken:0,status:'active'});refresh();}
  ensure();date.addEventListener('change',ensure);window.addEventListener('storage',refresh);
  btn.textContent='Set now serving';btn.addEventListener('click',()=>{const n=Number(input.value),issued=bookings().length;if(!Number.isInteger(n)||n<0||n>issued){status.textContent=`Enter a token from 0 to ${issued}.`;return;}const q=read();q.currentServingToken=n;save(q);refresh();status.textContent='Queue updated for this browser demo.';});
  const next=document.createElement('button');next.type='button';next.className='btn btn-secondary';next.textContent='Next patient';btn.insertAdjacentElement('afterend',next);
  next.addEventListener('click',()=>{const q=read(),issued=bookings().length,n=Number(q.currentServingToken||0)+1;if(n>issued){status.textContent='No more booked patients in this queue.';return;}q.currentServingToken=n;save(q);refresh();});
  const pause=document.createElement('button');pause.type='button';pause.className='btn btn-secondary';pause.textContent='Pause / resume';next.insertAdjacentElement('afterend',pause);
  pause.addEventListener('click',()=>{const q=read();q.status=q.status==='paused'?'active':'paused';save(q);refresh();status.textContent=q.status==='paused'?'Queue paused.':'Queue resumed.';});
 }
 async function startDoctorQueue(){
  const input=el('current-serving-input'),btn=el('save-current-serving'),status=el('queue-control-status');
  const panel=input.closest('.panel');
  const date=document.createElement('input');date.type='date';date.className='input';date.id='doctor-queue-date';date.value=today();
  const label=document.createElement('label');label.className='field';label.textContent='Queue date';label.appendChild(date);panel.insertBefore(label,input.parentElement||btn);
  const who=await new Promise(resolve=>hcAuth.onAuthStateChanged(resolve));
  if(!who){status.textContent='Please sign in with the doctor account.';btn.disabled=true;return;}
  const profileSnap=await hcDb.collection('users').doc(who.uid).get();const profile=profileSnap.exists?profileSnap.data():{};
  if(profile.role!=='doctor'||!profile.doctorId){status.textContent='This account is not assigned to a doctor profile. Ask the HospiCare administrator to set role=doctor and doctorId in users/'+who.uid+'.';btn.disabled=true;return;}
  let currentRef=null,unsub=null;
  async function attach(){if(unsub)unsub();const ref=queueRef(profile.doctorId,date.value);currentRef=ref;
   try{await ref.set({hospitalId:profile.hospitalId||'',doctorId:profile.doctorId,queueDate:date.value,currentServingToken:0,lastIssuedToken:0,status:'active',updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});}catch(e){status.textContent='Cannot access this queue: '+e.message;return;}
   unsub=ref.onSnapshot(s=>{if(s.exists){const q=s.data();input.value=q.currentServingToken||0;status.textContent=`Live queue · ${pad(q.currentServingToken||0)} being served · ${q.lastIssuedToken||0} tokens issued · ${q.status||'active'}`;}});
  }
  await attach();date.addEventListener('change',attach);
  btn.textContent='Set now serving';btn.addEventListener('click',async()=>{
   const n=Number(input.value);if(!Number.isInteger(n)||n<0){status.textContent='Enter a valid token number (0 or higher).';return;}
   try{await currentRef.update({currentServingToken:n,updatedAt:firebase.firestore.FieldValue.serverTimestamp()});status.textContent='Queue updated. Patients watching this doctor will see the change automatically.';}catch(e){status.textContent='Update failed: '+e.message;}
  });
  const next=document.createElement('button');next.type='button';next.className='btn btn-secondary';next.textContent='Next patient';btn.insertAdjacentElement('afterend',next);
  next.addEventListener('click',async()=>{try{await hcDb.runTransaction(async tx=>{const s=await tx.get(currentRef);if(!s.exists)throw Error('Queue not initialized');const q=s.data(),n=Number(q.currentServingToken||0)+1;if(n>Number(q.lastIssuedToken||0))throw Error('No more issued tokens in this queue.');tx.update(currentRef,{currentServingToken:n,updatedAt:firebase.firestore.FieldValue.serverTimestamp()});});}catch(e){status.textContent=e.message;}});
  const pause=document.createElement('button');pause.type='button';pause.className='btn btn-secondary';pause.textContent='Pause / resume';next.insertAdjacentElement('afterend',pause);
  pause.addEventListener('click',async()=>{try{const s=await currentRef.get(),paused=s.data()?.status==='paused';await currentRef.update({status:paused?'active':'paused',updatedAt:firebase.firestore.FieldValue.serverTimestamp()});}catch(e){status.textContent=e.message;}});
 }
})();
