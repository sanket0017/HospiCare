/* HospiCare Firebase integration (Firebase compat SDK). */
(() => {
  const cfg = window.HOSPICARE_FIREBASE_CONFIG;
  const ready = cfg && cfg.apiKey && !cfg.apiKey.includes('PASTE_') && window.firebase;
  if (!ready) {
    window.HC_FIREBASE_READY = false;
    window.HC_FIREBASE_ERROR = 'Add your Firebase Web API key in js/firebase-config.js.';
    return;
  }
  try {
    if (!firebase.apps.length) firebase.initializeApp(cfg);
    window.hcAuth = firebase.auth();
    window.hcDb = firebase.firestore();
    window.HC_FIREBASE_READY = true;
  } catch (e) {
    window.HC_FIREBASE_READY = false;
    window.HC_FIREBASE_ERROR = e.message;
  }

  const $ = (s, root=document) => root.querySelector(s);
  const safe = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const show = (el, msg, bad=false) => { if(el){el.textContent=msg;el.style.color=bad?'#b42318':'#087f73';} };
  const errText = e => ({'auth/email-already-in-use':'This email already has an account. Please sign in.','auth/invalid-email':'Enter a valid email address.','auth/weak-password':'Use a password with at least 6 characters.','auth/user-not-found':'No account found for this email.','auth/wrong-password':'Incorrect password.','auth/invalid-credential':'Email or password is incorrect.','auth/too-many-requests':'Too many attempts. Wait a few minutes and try again.','auth/network-request-failed':'Network error. Check your internet connection and try again.','auth/invalid-api-key':'Firebase API key is invalid. Check js/firebase-config.js.','auth/operation-not-allowed':'Email/password sign-in is not enabled in Firebase Authentication.','permission-denied':'Firebase blocked this action. Check the Firestore security rules.'}[e.code] || e.message || 'Something went wrong. Please try again.');
  const requireFirebase = () => { if(!window.HC_FIREBASE_READY) throw new Error(window.HC_FIREBASE_ERROR || 'Firebase is not configured.'); };

  // Register and sign-in pages.
  document.addEventListener('submit', async e => {
    const form=e.target;
    if(form.matches('#firebase-register-form') || form.matches('#loginForm')) {
      e.preventDefault(); e.stopImmediatePropagation();
      const msg=$('#msg') || $('#register-msg');
      try {
        requireFirebase();
        if(form.matches('#firebase-register-form')) {
          const name=$('#reg-name').value.trim(), email=$('#reg-email').value.trim().toLowerCase(), phone=$('#reg-phone').value.trim(), password=$('#reg-password').value;
          if(!/^\d{10}$/.test(phone)) throw new Error('Enter a valid 10-digit mobile number.');
          const cred=await hcAuth.createUserWithEmailAndPassword(email,password);
          await cred.user.updateProfile({displayName:name});
          await hcDb.collection('users').doc(cred.user.uid).set({name,email,phone,role:'patient',createdAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
          location.href='patient-dashboard.html';
        } else {
          const role=form.querySelector('[data-role][aria-pressed="true"]')?.dataset.role || 'patient';
          const email=$('#email').value.trim().toLowerCase(), password=$('#password').value;
          const cred=await hcAuth.signInWithEmailAndPassword(email,password);
          const userRef=hcDb.collection('users').doc(cred.user.uid);
          const snap=await userRef.get();
          let profile=snap.exists?snap.data():{};
          // Recover accounts created in Firebase Auth before their Firestore profile
          // was saved. This is safe for patients only; staff roles must be assigned
          // by an administrator and are never self-created during login.
          if(!snap.exists && role==='patient') {
            profile={name:cred.user.displayName||'',email:cred.user.email||email,role:'patient'};
            await userRef.set({...profile,createdAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
          }
          const profileRole = profile.role === 'hospital_manager' ? 'manager' : profile.role;
          if(role==='patient' && profile.role && profileRole!=='patient') throw new Error('This account is not registered as a patient.');
          if(role!=='patient' && profileRole!==role) throw new Error('This account does not have the selected staff role. Ask the project administrator to assign it.');
          const destination=role==='doctor'?'doctor-dashboard.html':role==='manager'?'manager-dashboard.html':'patient-dashboard.html';
          const returnTo=new URLSearchParams(location.search).get('return');
          location.href=role==='patient' ? (returnTo==='appointment.html'?'appointment.html':'index.html') : destination;
        }
      } catch(err){console.error('HospiCare authentication error:',err);show(msg,errText(err),true);}
    }
  }, true);

  // Appointment booking is written to Firestore. A signed-in patient is required.
  document.addEventListener('submit', async e => {
    const form=e.target;
    if(!form.matches('#appointment-form')) return;
    e.preventDefault(); e.stopImmediatePropagation();
    const err=$('#step-error');
    try {
      requireFirebase();
      const user=hcAuth.currentUser;
      if(!user) throw new Error('Please sign in with your patient account before confirming the appointment.');
      const patientProfileSnap=await hcDb.collection('users').doc(user.uid).get();
      if(!patientProfileSnap.exists || patientProfileSnap.data().role!=='patient') throw new Error('Only a patient account can book an appointment.');
      if(!form.reportValidity()) return;
      const data=Object.fromEntries(new FormData(form).entries());
      const doctorId=String(data.doctorId||'').trim(), hospitalId=String(data.hospitalId||'').trim();
      if(!doctorId || !hospitalId) throw new Error('The selected doctor or hospital is missing its directory ID. Please reopen the booking page.');
      const [doctorSnap,hospitalSnap]=await Promise.all([
        hcDb.collection('doctors').doc(doctorId).get(), hcDb.collection('hospitals').doc(hospitalId).get()
      ]);
      if(!doctorSnap.exists || !hospitalSnap.exists) throw new Error('The selected doctor or hospital is not registered in Firestore.');
      const doctorRecord=doctorSnap.data(), hospitalRecord=hospitalSnap.data();
      if(doctorRecord.hospitalId!==hospitalId || hospitalRecord.status==='inactive') throw new Error('This doctor is not assigned to the selected active hospital.');
      const queueId=doctorId+'_'+data.date;
      const queueRef=hcDb.collection('queues').doc(queueId);
      const availabilityRef=hcDb.collection('doctorAvailability').doc(doctorId);
      const slotKey=doctorId+'_'+data.date+'_'+data.time;
      const slotId=slotKey;
      const slotRef=hcDb.collection('slotLocks').doc(slotKey);
      const ref=hcDb.collection('appointments').doc();
      let payload;
      await hcDb.runTransaction(async tx=>{
        const [qs, avs, lock] = await Promise.all([tx.get(queueRef),tx.get(availabilityRef),tx.get(slotRef)]);
        if(lock.exists) throw new Error('This time slot has just been booked. Please choose another slot.');
        if(avs.exists){
          const av=avs.data();
          const dateObj=new Date(data.date+'T12:00:00');
          const day=dateObj.getDay();
          const days=Array.isArray(av.availableDays)?av.availableDays:[];
          if(av.enabled===false || !days.includes(day)) throw new Error('The doctor is not available on the selected date.');
          const toMin=v=>{const raw=String(v||'').trim();let m=raw.match(/^(\d{1,2}):(\d{2})(?:\s*(AM|PM))?$/i);if(!m)return -1;let h=Number(m[1]),mi=Number(m[2]);if(m[3]){if(h===12)h=0;if(m[3].toUpperCase()==='PM')h+=12;}return h*60+mi;};
          const slotMin=toMin(data.time);
          if(slotMin<toMin(av.startTime)||slotMin>=toMin(av.endTime)||((slotMin-toMin(av.startTime))%Number(av.slotMinutes||30))!==0) throw new Error('The selected time is outside the doctor availability.');
        } else {
          throw new Error('The doctor has not published availability yet. Please try again later.');
        }
        const old=qs.exists?qs.data():{};
        const count=Number(old.lastIssuedToken||0)+1;
        const token='HC-'+String(count).padStart(3,'0');
        payload={patientId:user.uid,patientName:data.name,patientEmail:user.email||'',phone:data.phone,age:Number(data.age),reason:data.reason||'',hospital:data.hospital,hospitalId,doctor:data.doctor,doctorId,appointmentDate:data.date,appointmentTime:data.time,status:'booked',tokenNumber:count,token,queueId,slotId,createdAt:firebase.firestore.FieldValue.serverTimestamp()};
        tx.set(ref,payload);
        tx.set(slotRef,{doctorId,hospitalId,appointmentDate:data.date,appointmentTime:data.time,appointmentId:ref.id,createdAt:firebase.firestore.FieldValue.serverTimestamp()});
        const queueUpdate={queueDate:data.date,lastIssuedToken:count,lastAppointmentId:ref.id,updatedAt:firebase.firestore.FieldValue.serverTimestamp()};
        if(qs.exists){
          // Existing queue metadata is retained; only the booking counter is advanced.
          tx.update(queueRef,queueUpdate);
        } else {
          tx.set(queueRef,{hospitalId,doctorId,queueDate:data.date,currentServingToken:0,status:'active',averageConsultationMinutes:10,...queueUpdate});
        }
      });
      await hcDb.collection('users').doc(user.uid).set({name:data.name,email:user.email||'',phone:data.phone,age:Number(data.age),role:'patient',updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
      const saved={...payload,id:ref.id};
      sessionStorage.setItem('hospicare_latest_token',JSON.stringify(saved));
      location.href='token.html';
    } catch(ex){show(err,errText(ex),true); if(err)err.hidden=false;}
  }, true);

  document.addEventListener('click', async e => {
    if(e.target.closest('#forgot')) { e.preventDefault(); e.stopImmediatePropagation(); try { requireFirebase(); const email=$('#email').value.trim(); if(!email) throw new Error('Enter your email address first.'); await hcAuth.sendPasswordResetEmail(email); show($('#msg'),'Password reset email sent. Check your inbox.'); } catch(ex){ show($('#msg'),errText(ex),true); } }
  }, true);

  // Booking page inline account actions use Firebase Auth.
  document.addEventListener('DOMContentLoaded', () => {
    const create=$('#booking-account-create'), login=$('#booking-account-login'), status=$('#booking-account-status');
    create?.addEventListener('click',async ev=>{ev.preventDefault();ev.stopImmediatePropagation();try{requireFirebase();const email=$('#booking-account-email').value.trim(),password=$('#booking-account-password').value;await hcAuth.createUserWithEmailAndPassword(email,password);show(status,'Account created. Complete your appointment.');}catch(e){show(status,errText(e),true);}},{capture:true});
    login?.addEventListener('click',async ev=>{ev.preventDefault();ev.stopImmediatePropagation();try{requireFirebase();const email=$('#booking-account-email').value.trim(),password=$('#booking-account-password').value;await hcAuth.signInWithEmailAndPassword(email,password);show(status,'Signed in as '+email);}catch(e){show(status,errText(e),true);}},{capture:true});
  });

  // Token page reads the saved Firestore appointment ID.
  document.addEventListener('DOMContentLoaded',async()=>{
    const tokenEl=$('#token-number'); if(!tokenEl) return;
    try{requireFirebase();const saved=JSON.parse(sessionStorage.getItem('hospicare_latest_token')||'null');if(!saved?.id)return;
      const snap=await hcDb.collection('appointments').doc(saved.id).get();if(!snap.exists)return;const a=snap.data();
      tokenEl.textContent=a.token||('HC-'+String(a.tokenNumber).padStart(3,'0'));
      $('#token-details').innerHTML=`<p><b>${safe(a.patientName)}</b> · Patient</p><p>${safe(a.hospital)}</p><p>${safe(a.doctor)}</p><p>${safe(a.appointmentDate)} · ${safe(a.appointmentTime)}</p>`;
    }catch(e){console.warn('Token lookup:',e);}
  });

  // Patient dashboard/history is scoped to the signed-in patient.
  document.addEventListener('DOMContentLoaded',async()=>{
    if(!$('#history') && !document.querySelector('[data-patient-dashboard]') && !$('#my-count')) return;
    try{requireFirebase();hcAuth.onAuthStateChanged(async user=>{if(!user)return;try{
      const snap=await hcDb.collection('appointments').where('patientId','==',user.uid).get();
      const all=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0));
      if($('#total'))$('#total').textContent=all.length;if($('#upcoming'))$('#upcoming').textContent=all.filter(a=>a.status==='booked').length;if($('#latest'))$('#latest').textContent=all[0]?.token||'—';
      if($('#history')&&all.length)$('#history').innerHTML=all.map(a=>`<div class="history-item"><div><b>${safe(a.hospital)}</b><small>${safe(a.doctor)} · ${safe(a.appointmentDate)} at ${safe(a.appointmentTime)} · ${safe(a.patientName)}</small></div><b>${safe(a.token||'')}</b></div>`).join('');
      if($('#my-profile')){const p=await hcDb.collection('users').doc(user.uid).get();const x=p.exists?p.data():{};$('#my-profile').innerHTML=`<p><b>${safe(x.name||user.displayName||'Patient')}</b></p><p>${safe(user.email||'')}</p><p>${safe(x.phone||'')}</p>`;}
      if($('#my-appointments'))$('#my-appointments').innerHTML=all.length?all.map(a=>`<div class="history-item"><div><b>${safe(a.hospital)}</b><small>${safe(a.doctor)} · ${safe(a.appointmentDate)} at ${safe(a.appointmentTime)}</small></div><b>${safe(a.token||'')}</b></div>`).join(''):'No saved appointments yet.';
      if($('#my-count'))$('#my-count').textContent=all.length;if($('#my-token'))$('#my-token').textContent=all[0]?.token||'—';if($('#my-upcoming'))$('#my-upcoming').textContent=all.filter(a=>a.status==='booked').length;
    }catch(e){console.warn('Dashboard lookup:',e);}});}catch(e){console.warn('Dashboard lookup:',e);}
  });

  // Populate directory pages from Firestore when collections contain records; keep curated UI as fallback.
  document.addEventListener('DOMContentLoaded',async()=>{
    try{requireFirebase();
      const hg=$('#hospital-grid'); if(hg){const s=await hcDb.collection('hospitals').where('status','==','active').get();if(!s.empty){hg.insertAdjacentHTML('beforeend',s.docs.map(d=>{const x=d.data();return `<article class="card pick directory-card"><div class="art">＋</div><span class="tag">HospiCare directory</span><h3>${safe(x.name)}</h3><p class="detail-line">${safe(x.address||'')} · ${safe(x.city||'')}</p><span class="partner-status">Directory record · verify details before visiting</span><div class="card-actions"><a class="btn btn-primary" href="appointment.html?hospital=${encodeURIComponent(x.name||'')}">Book appointment</a></div></article>`}).join(''));}}
      const dg=$('#doctor-grid'); if(dg){const s=await hcDb.collection('doctors').where('status','==','active').get();if(!s.empty){dg.insertAdjacentHTML('beforeend',s.docs.map(d=>{const x=d.data();return `<article class="doctor-profile-card"><div class="doctor-card-top"><div class="doctor-avatar">${safe((x.name||'D').split(' ').slice(-1)[0].slice(0,2).toUpperCase())}</div><span class="tag">${safe(x.specialization||'Specialist')}</span></div><h2>${safe(x.name)}</h2><p class="doctor-hospital">${safe(x.hospitalId||'')}</p><div class="doctor-rating"><b>HospiCare directory</b></div><p>Consultation fee: ₹${safe(x.fee??'—')}</p><div class="doctor-card-actions"><a class="btn btn-primary" href="appointment.html?doctor=${encodeURIComponent(x.name||'')}">Book appointment</a><a class="btn btn-secondary" href="queue.html?doctorId=${encodeURIComponent(d.id)}">View live queue</a></div></article>`}).join(''));}}
    }catch(e){console.warn('Directory lookup; using included demo cards:',e);}
  });
})();
